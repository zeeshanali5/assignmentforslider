let cPic= document.querySelector(".pica");
let nexButton= document.querySelector(".Next")
let prevButton= document.querySelector(".Previous")

nexButton.addEventListener("click", () => {
    displayImage.src.match("e.jpg")
});

prevButtonButton.addEventListener("click", () => {
    displayImage.src.match("a.jpg")
});
